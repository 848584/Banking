package com.cognizant.Accounts;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;



@FeignClient(name="netflix-zuul-api-gateway-server")
@RibbonClient(name="balance-enquiry-service")
public interface BalanceEnquiryProxy {
	@GetMapping("balance-enquiry-service/balance/{accountNumber}")
	public AccountBean retrieveInfo(@PathVariable("accountNumber") String accountNumber);

}
