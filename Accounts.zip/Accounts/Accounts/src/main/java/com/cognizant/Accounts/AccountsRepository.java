package com.cognizant.Accounts;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

public interface AccountsRepository extends CrudRepository<AccountBean, String>{
	
	AccountBean findByAccountNumber(String accountNumber);

}
