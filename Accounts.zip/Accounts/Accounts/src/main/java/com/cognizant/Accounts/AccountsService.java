package com.cognizant.Accounts;

import java.math.BigDecimal;
import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@Component
public class AccountsService {
	@Autowired
	private AccountsRepository repository;
	
	@Autowired
	private BalanceEnquiryProxy proxy;

	public AccountBean findInfo(String accountNumber)
	{
		AccountBean response=proxy.retrieveInfo(accountNumber);
		AccountBean accountBean = repository.findByAccountNumber(accountNumber);
		return new AccountBean(accountBean.getAccountNumber(),accountBean.getName(),accountBean.getIfscCode(),response.getBalance());
	}
	
	public AccountBean saveUser(AccountBean account)
	{
		AccountBean bean= repository.save(account);
		return new AccountBean(bean.getAccountNumber(),bean.getName(),"1234",BigDecimal.ZERO);
		
	}
	
	
}
