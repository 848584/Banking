package com.cognizant.Accounts;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.math.BigDecimal;
import java.net.URI;

@RestController
public class AccountController {
	
	@Autowired
	AccountsService accountService;
	
	
	@GetMapping("/Accounts/{accountNumber}")
	public AccountBean retrieveInfo(@PathVariable String accountNumber)
	{	
		return accountService.findInfo(accountNumber);
	}
	
	@PostMapping("Accounts")
	public ResponseEntity<Object> saveAccount(@RequestBody AccountBean account)
	{
		AccountBean ab=accountService.saveUser(account);
		URI location=ServletUriComponentsBuilder.fromCurrentRequest()  
				.path("/{accountNumber}")
				.buildAndExpand(ab.getAccountNumber()) 
				.toUri();
				
				return ResponseEntity.created(location).build();
	}
	

}
