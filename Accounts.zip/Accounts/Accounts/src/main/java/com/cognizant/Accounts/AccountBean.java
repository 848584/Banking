package com.cognizant.Accounts;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class AccountBean {
	@Id
	private String accountNumber;
	private String name;
	private String ifscCode;
	private BigDecimal balance;
	
	public AccountBean()
	{		
	}
	
	public AccountBean(String accountNumber, String name, String ifscCode,BigDecimal balance) {
		super();
		this.accountNumber = accountNumber;
		this.name = name;
		this.ifscCode = ifscCode;
		this.balance = balance;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public String getName() {
		return name;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public BigDecimal getBalance() {
		return balance;
	}
	
	
	

}
