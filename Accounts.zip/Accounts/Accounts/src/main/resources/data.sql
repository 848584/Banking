insert into account_bean(account_number,name,ifsc_code)
values(10001,'john','1234');
insert into account_bean(account_number,name,ifsc_code)
values(10002,'javed','1234');
insert into account_bean(account_number,name,ifsc_code)
values(10003,'riya','1234');
