insert into balance_enquiry_bean(account_number,balance)
values(10001,567);
insert into balance_enquiry_bean(account_number,balance)
values('10002',653);
insert into balance_enquiry_bean(account_number,balance)
values('10003',8786);
