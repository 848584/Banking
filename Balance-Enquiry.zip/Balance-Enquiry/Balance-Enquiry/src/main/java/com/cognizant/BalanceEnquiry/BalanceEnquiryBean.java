package com.cognizant.BalanceEnquiry;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class BalanceEnquiryBean {

	@Id
	private String accountNumber;
	private BigDecimal balance;
	

	public BalanceEnquiryBean() {
	}

	public BalanceEnquiryBean(String accountNumber, BigDecimal balance) {
		super();
		this.accountNumber = accountNumber;
		this.balance = balance;
	}


	public String getAccountNumber() {
		return accountNumber;
	}


	public BigDecimal getBalance() {
		return balance;
	}
	
	
}
