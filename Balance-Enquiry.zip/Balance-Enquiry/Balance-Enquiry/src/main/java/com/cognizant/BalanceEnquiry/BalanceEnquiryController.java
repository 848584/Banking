package com.cognizant.BalanceEnquiry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class BalanceEnquiryController {
	
	@Autowired
	private BalanceEnquiryRepository repository;
	
	@GetMapping("/balance/{accountNumber}")
	public BalanceEnquiryBean retrieveInfo(@PathVariable String accountNumber)
	{
		BalanceEnquiryBean balanceEnquiryBean=repository.findByAccountNumber(accountNumber);
		return balanceEnquiryBean;
	}
	
	
	

}
